do {
    numero = prompt("Ingrese un número para visualizarlo por consola o SALIR para salir.");
    console.log("Tu elección es " + numero);
} while (numero !== "SALIR");
alert("¡Creí que estaríamos ahí por siempre!");
console.log("¡Gracias por participar!")